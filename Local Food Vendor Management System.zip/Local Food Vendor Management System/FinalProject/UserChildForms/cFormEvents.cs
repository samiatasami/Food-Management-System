﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject.UserChildForms
{
    public partial class cFormEvents : Form
    {
        public cFormEvents()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            string s = "SELECT * FROM Events";
            dataGridView2.DataSource = SaleDAL.sqlHelp.ExecuteQuery(s);
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void cFormEvents_Load(object sender, EventArgs e)
        {
            dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            string s1 = "SELECT * FROM Events";
            dataGridView2.DataSource = SaleDAL.sqlHelp.ExecuteQuery(s1);
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            string s2 = "WITH NormalizedSales AS (SELECT e.eventid, e.eventname, e.eventdate, COUNT(s.sale_id) AS number_of_sales, SUM(CAST(s.total_price AS DECIMAL(18, 2))) AS total_sales, MAX(SUM(CAST(s.total_price AS DECIMAL(18, 2)))) OVER () AS max_total_sales, MAX(COUNT(s.sale_id)) OVER () AS max_number_of_sales FROM events e JOIN tbl_sales s ON e.eventdate = s.date GROUP BY e.eventid, e.eventname, e.eventdate) SELECT TOP 10 eventid, eventname, eventdate, number_of_sales, total_sales, (total_sales / max_total_sales) + (number_of_sales / max_number_of_sales) AS composite_score FROM NormalizedSales ORDER BY composite_score DESC;";
            dataGridView1.DataSource = SaleDAL.sqlHelp.ExecuteQuery(s2);
        }

        private void button2_Click_2(object sender, EventArgs e)
        {
            string s = "SELECT * FROM Events";
            dataGridView2.DataSource = SaleDAL.sqlHelp.ExecuteQuery(s);
        }
    }
}
