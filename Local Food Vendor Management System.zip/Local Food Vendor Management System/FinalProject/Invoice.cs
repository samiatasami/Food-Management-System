﻿using FinalProject.AdminChildForms;
using FinalProject.UserChildForms;
using SaleBLL;
using SaleDAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class Invoice : Form
    {
        public Invoice()
        {
            InitializeComponent();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Rectangle m = e.PageBounds;
            e.Graphics.DrawImage(BitmaptoPrint, m);
        }

        private void Invoice_Load(object sender, EventArgs e)
        {
            if(cFormUserSales.name != null)
            {
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                textBox1.Text = cFormUserSales.name;
                DataTable result = sqlHelp.ExecuteQuery($"SELECT address FROM tbl_users WHERE username = '{cFormUserSales.name}'");
                richTextBox2.Text = result.Rows[0][0].ToString();
                string s = $"SELECT TOP 1 id,order_date,food_name,quantity,total_price FROM customerorders WHERE customer_name = '{cFormUserSales.name}' ORDER BY id DESC";
                DataTable dt = sqlHelp.ExecuteQuery(s);
                dataGridView1.DataSource = dt;
            }
            else
            {
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                textBox1.Text = cFormSales.name;
                DataTable result = sqlHelp.ExecuteQuery($"SELECT address FROM tbl_users WHERE username = '{cFormSales.name}'");
                richTextBox2.Text = result.Rows[0][0].ToString();
                string s = $"SELECT TOP 1 id,order_date,food_name,quantity,total_price FROM customerorders WHERE customer_name = '{cFormSales.name}' ORDER BY id DESC";
                DataTable dt = sqlHelp.ExecuteQuery(s);
                dataGridView1.DataSource = dt;
            }
            
        }
        Bitmap BitmaptoPrint;
        private void CaptureFormShot()
        {
            BitmaptoPrint = new Bitmap(this.Width, this.Height);
            this.DrawToBitmap(BitmaptoPrint, new Rectangle(0, 0, this.Width, this.Height));
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CaptureFormShot();
            printPreviewDialog1.ShowDialog();
        }

        private void printPreviewDialog1_Load(object sender, EventArgs e)
        {

        }
    }
}
