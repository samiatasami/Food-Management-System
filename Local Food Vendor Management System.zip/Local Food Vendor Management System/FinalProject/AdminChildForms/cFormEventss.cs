﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using SaleBLL;
using SaleDAL;

namespace FinalProject.AdminChildForms
{
    public partial class cFormEventss : Form
    {
        //objects for classes
        public informations info = new informations();
        public Users users = new Users();

        //fields
        private Button currentBtn;
        private Button previousBtn;
        private Image defaultImage;
        private Panel leftBorderBtn;
        private Form currentChildForm;
        Thread th;
        private struct RGBColors
        {
            public static Color white = Color.White;
            public static Color textColor1 = Color.FromArgb(26, 25, 62);
            public static Color backColor1 = Color.FromArgb(31, 30, 68);
            public static Color backColor2 = Color.FromArgb(37, 36, 81);

            public static Color color0 = Color.FromArgb(172, 126, 241);
            public static Color color1 = Color.FromArgb(249, 118, 176);
            public static Color color2 = Color.FromArgb(253, 138, 114);
            public static Color color3 = Color.FromArgb(95, 77, 221);
            public static Color color4 = Color.FromArgb(249, 88, 155);
            public static Color color5 = Color.FromArgb(78, 185, 85);
            public static Color color6 = Color.FromArgb(24, 161, 251);
        }
        private void disableButton(Image defaultImagecur)
        {
            if (currentBtn != null)
            {
                if (previousBtn != null)
                {
                    previousBtn.Image = defaultImage;
                    previousBtn.BackColor = RGBColors.backColor1;
                    previousBtn.ForeColor = RGBColors.white;
                    previousBtn.TextAlign = ContentAlignment.MiddleLeft;
                    previousBtn.ImageAlign = ContentAlignment.MiddleCenter;
                }
                previousBtn = currentBtn;
                defaultImage = defaultImagecur;
            }
        }
        private void activeButton(object senderbtn, Color color, Image defaultImagecur, Image changedimage)
        {
            if (senderbtn != null)
            {
                currentBtn = (Button)senderbtn;
                disableButton(defaultImagecur);

                currentBtn.BackColor = RGBColors.backColor2;
                currentBtn.ForeColor = color;
                currentBtn.Image = changedimage;
                currentBtn.TextAlign = ContentAlignment.MiddleCenter;
                currentBtn.ImageAlign = ContentAlignment.MiddleRight;

                //Left border before button
               leftBorderBtn.BackColor = color;
                leftBorderBtn.Location = new Point(0, currentBtn.Location.Y);
                leftBorderBtn.Visible = true;
                leftBorderBtn.BringToFront();

            }
        }
        
        public cFormEventss()
        {
            InitializeComponent();
        }

        
        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            string s1 = "SELECT * FROM Events";
            dataGridView2.DataSource = SaleDAL.sqlHelp.ExecuteQuery(s1);
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            string s2 = "WITH NormalizedSales AS (SELECT e.eventid, e.eventname, e.eventdate, COUNT(s.sale_id) AS number_of_sales, SUM(CAST(s.total_price AS DECIMAL(18, 2))) AS total_sales, MAX(SUM(CAST(s.total_price AS DECIMAL(18, 2)))) OVER () AS max_total_sales, MAX(COUNT(s.sale_id)) OVER () AS max_number_of_sales FROM events e JOIN tbl_sales s ON e.eventdate = s.date GROUP BY e.eventid, e.eventname, e.eventdate) SELECT TOP 10 eventid, eventname, eventdate, number_of_sales, total_sales, (total_sales / max_total_sales) + (number_of_sales / max_number_of_sales) AS composite_score FROM NormalizedSales ORDER BY composite_score DESC;";
            dataGridView1.DataSource = SaleDAL.sqlHelp.ExecuteQuery(s2);
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Image defaultImagecur = Properties.Resources.info;
            Image changedimage = Properties.Resources.infoColor;
           
           
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
           
        }
        
    private void button4_Click(object sender, EventArgs e)
        {
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                string s = $"INSERT INTO Events(eventname,eventdate) VALUES('{textBox1.Text}','{textBox2.Text}')";
                int i = sqlHelp.ExecuteUpdate(s);
                if (i > 0)
                {
                    MessageBox.Show("Event Added Successfully", "success", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    MessageBox.Show("Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Please enter the event name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                string s = $"UPDATE Events SET eventdate = '{textBox2.Text}' WHERE eventname = '{textBox1.Text}'";
                int i = sqlHelp.ExecuteUpdate(s);
                if (i > 0)
                {
                    MessageBox.Show("Event Updated Successfully", "success", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    MessageBox.Show("Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Please enter the event name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            string s = "SELECT * FROM Events";
            dataGridView2.DataSource = SaleDAL.sqlHelp.ExecuteQuery(s);
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                string s = $"DELETE FROM Events WHERE eventname = '{textBox1.Text}'";
                int i = sqlHelp.ExecuteUpdate(s);
                if (i > 0)
                {
                    MessageBox.Show("Event Deleted Successfully", "success", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    MessageBox.Show("Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Please enter the event name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
