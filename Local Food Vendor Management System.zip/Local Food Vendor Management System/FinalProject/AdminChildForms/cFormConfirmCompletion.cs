﻿using SaleDAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject.AdminChildForms
{
    public partial class cFormConfirmCompletion : Form
    {
        public cFormConfirmCompletion()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void cFormConfirmCompletion_Load(object sender, EventArgs e)
        {
            string query = "SELECT id FROM customerorders WHERE queue_status = 'false'";
            DataTable queueData = sqlHelp.ExecuteQuery(query);
            foreach (DataRow row in queueData.Rows)
            {
                comboBox1.Items.Add(row["id"].ToString());
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {

                string s = $"UPDATE customerorders SET queue_number = 0, Queue_Status ='true' WHERE id = '{comboBox1.SelectedItem}';";
                int i = sqlHelp.ExecuteUpdate(s);
                s = $"UPDATE customerorders SET queue_number = queue_number - 1 WHERE id <> '{comboBox1.SelectedItem}' AND queue_status = 'false';";
                sqlHelp.ExecuteUpdate(s);
                if (i > 0)
                {
                    MessageBox.Show("success");
                }

            }
            else
            {
                MessageBox.Show("Please Check The Box!");
            }
        }
    }
}
