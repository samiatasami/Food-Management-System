﻿using SaleDAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace FinalProject
{
    public partial class Sellprod : Form
    {
        public Sellprod()
        {
            InitializeComponent();
        }

        private void Sellprod_Load(object sender, EventArgs e)
        {
             dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            string s = "WITH RankedProducts AS (SELECT co.food_name, e.Eventdate, e.EventName, SUM(co.quantity) AS total_quantity, RANK() OVER (PARTITION BY e.Eventdate ORDER BY SUM(co.quantity) DESC) AS rank FROM customerorders co JOIN Events e ON co.order_date = e.Eventdate GROUP BY co.food_name, e.Eventdate, e.EventName) SELECT EventName, food_name, total_quantity FROM RankedProducts WHERE rank = 1;";
            dataGridView1.DataSource = SaleDAL.sqlHelp.ExecuteQuery(s);
        }
        

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
